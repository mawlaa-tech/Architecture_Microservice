using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ui.Pages.Account;

public class AccessDeniedModel : PageModel
{
    public void OnGet()
    {
    }
}