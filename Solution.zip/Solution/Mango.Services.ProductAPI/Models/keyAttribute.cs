﻿using System;

namespace Mango.Services.ProductAPI.Models
{
    internal class keyAttribute : Attribute
    {
    }
}