﻿using System;

namespace ProductTest
{
    internal class FactAttribute : Attribute
    {
    }
}