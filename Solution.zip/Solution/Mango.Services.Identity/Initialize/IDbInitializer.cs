﻿namespace Mango.Services.Identity.Initialize
{
    public interface IDbInitializer
    {
        public void Initialize();
    }
}